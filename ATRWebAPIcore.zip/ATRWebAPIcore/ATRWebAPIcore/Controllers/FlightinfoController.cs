﻿using ATRWebAPIcore.models;
using ATRWebAPIcore.Repository_DI;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ATRWebAPIcore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightinfoController : ControllerBase
    {
        private readonly IFlight flight = null;
        public FlightinfoController(IFlight flight)
        {
            this.flight = flight;
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetFlightInfoByID(int id)
        {
            var user = await flight.GetFlightInfoByID(id);
            if (user != null)
            {
                return Ok(user);
            }
            else
            {
                return NotFound();
            }
        }
       [HttpPost]
        public async Task<IActionResult> AddNewFlight([FromBody] Flight plane)
        {
            int a = await flight.AddNewFlight(plane);
            return Ok(a);
        }
    }
}
