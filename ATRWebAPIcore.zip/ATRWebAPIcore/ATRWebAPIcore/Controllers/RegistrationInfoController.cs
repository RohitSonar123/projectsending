﻿using ATRWebAPIcore.models;
using ATRWebAPIcore.Repository_DI;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ATRWebAPIcore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationInfoController : ControllerBase
    {
        private readonly IRegistration registration = null;
        public RegistrationInfoController(IRegistration registration)
        {
            this.registration = registration;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllUsers()
        {
            var dept = await registration.GetUsers();
            return Ok(dept);
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByUserId(int id)
        {
            var user = await registration.GetById(id);
            if (user != null)
            {
                return Ok(user);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPost]
        public async Task<IActionResult> CreateUser([FromBody] Registration user)
        {
            int a = await registration.AddUser(user);
            return Ok(a);
        }
        [HttpPut]
        public async Task<IActionResult> UpdateUser([FromQuery] int id, [FromBody] Registration user)
        {
            int a = await registration.UpdateUser(id, user);
            return Ok(a);
        }


        [HttpGet("{mailId},{pass}")]
        public async Task<IActionResult>Login(string mailId,string pass)
        {
            var log =await registration.UserLogin(mailId, pass);
            return Ok(log);
        }
        [HttpDelete]
        //   [Route("{id}")]
        public async Task<IActionResult> DeleteUser([FromQuery] int id)
         {
             int a = await registration.DeleteUser(id);
             return Ok(a);
         } 
    }
}