﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;
using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations.Schema;
namespace ATRWebAPIcore.models
{
    public class Flight
    {
        [Required]
        [Key]
        public int FlightId { get; set; }
        [Required]
        public string FlightName { get; set; }
        [Required]
        public string Source { get; set; }
        [Required]
        public string Destination { get; set; }
        [Required]
        public DateTime DepartureDate { get; set; }
        [Required]
        public int NoOfTravellers { get; set; }
        [Required]
        public DateTime ReturnDate { get; set; }
        [Required]
        public int Class { get; set; }
        [Required(ErrorMessage = "pls enter UserID")]
        [Display(Name = "UserId")]
        [ForeignKey("UserId")]

        public int UserId { get; set; }
    }
}
