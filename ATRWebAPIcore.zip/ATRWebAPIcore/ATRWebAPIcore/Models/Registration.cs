﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ATRWebAPIcore.models
{
    public class Registration
    {

        [Display(Name = "UserId")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key()]
        

        public int UserId { get; set; }

        [Required(ErrorMessage = "Pls enter EmailId")]
        [Display(Name = "EmailId")]
      
        public string EmailId { get; set; }


        [Required(ErrorMessage = "Pls enter Password")]
        [Display(Name = "Password")]
        
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Pls enter the Password Again")]
        [Display(Name = " Confirm Password")]

        
        [DataType(DataType.Password)]
        [Compare("Password")]
        public string ConfirmPassword { get; set; }
        [Required]
        public string Firstname { get; set; }
        [Required]
        public string Lastname { get; set; }
        [Required]
        public long MobileNumber { get; set; }
        [Required]
        public string Gender { get; set; }




    }
}

