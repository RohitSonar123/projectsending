﻿using ATRWebAPIcore.DataAccessLayer;
using ATRWebAPIcore.models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ATRWebAPIcore.Repository_DI
{
    public class UserRepository : IRegistration
    {
        private readonly ATRSDbContext dbContext = null;

        public UserRepository(ATRSDbContext dbContext)
        {
            this.dbContext = dbContext;

        }
        public async Task<int> AddUser(Registration registration)
        {
            dbContext.Registrations.Add(registration);
            await dbContext.SaveChangesAsync();
            return registration.UserId;
        }


         public async Task<int> DeleteUser(int UserID)
         {
             var ar = await dbContext.Registrations.Where(x => x.UserId == UserID).FirstOrDefaultAsync();
             if (ar != null)
             {
                 dbContext.Registrations.Remove(ar);

             }
             await dbContext.SaveChangesAsync();
             return UserID;
         } 

        public async Task<Registration> GetById(int UserID)
        {
            var ar = await dbContext.Registrations.Where(x => x.UserId == UserID).FirstOrDefaultAsync();
            return ar;
        }

         public async Task<List<Registration>> GetUsers()
         {
             var ar = await dbContext.Registrations.ToListAsync();
             return ar;
         } 

        public async Task<int> UpdateUser(int UserID, Registration registration)
        {
            var ar = await dbContext.Registrations.Where(x => x.UserId == UserID).FirstOrDefaultAsync();
            if (ar != null)
            {
                ar.Firstname = registration.Firstname;
                ar.Lastname = registration.Lastname;
                ar.MobileNumber = registration.MobileNumber;
                ar.Password = registration.Password;

            }
            await dbContext.SaveChangesAsync();
            return UserID;
        }

        public async Task<Registration> UserLogin(string mailid,string pass)
        {
            var ar=await dbContext.Registrations.Where(x=>x.EmailId==mailid && x.Password==pass).FirstOrDefaultAsync();
            return ar;
        }
    }
}
