﻿using ATRWebAPIcore.models;


using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ATRWebAPIcore.Repository_DI

{
    public interface IFlight
    {
        //Task<Flight> GetFlightInfo(int UserID);
        Task<Flight> GetFlightInfoByID(int UserID);
        Task<int> AddNewFlight(Flight flight);

    }
}
