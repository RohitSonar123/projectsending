﻿using ATRWebAPIcore.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ATRWebAPIcore.Repository_DI
{
    public interface IRegistration
    {
        Task<List<Registration>> GetUsers();

        Task<Registration> GetById(int UserID);
        Task<int> AddUser(Registration registration);

        Task<int> UpdateUser(int UserID, Registration registration);
        Task<int> DeleteUser(int UserID);
        Task<Registration> UserLogin(string mailId, string pass);


    }
}
