﻿using ATRWebAPIcore.DataAccessLayer;
using ATRWebAPIcore.models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace ATRWebAPIcore.Repository_DI
{
    public class FlightRepository:IFlight
    {
        private readonly ATRSDbContext dbContext = null;

        public FlightRepository(ATRSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<Flight> GetFlightInfoByID(int FlightID)
        {
            var ar = await dbContext.Flights.Where(x => x.FlightId == FlightID).FirstOrDefaultAsync();
            return ar;
        }
        public async Task<int> AddNewFlight(Flight flight)
        {
            dbContext.Flights.Add(flight);
            await dbContext.SaveChangesAsync();
            return flight.UserId;
        }
    }


}

