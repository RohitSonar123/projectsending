﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ATRWebAPIcore.models;
using Microsoft.EntityFrameworkCore;

namespace ATRWebAPIcore.DataAccessLayer
{
    public class ATRSDbContext : DbContext
    {
        public ATRSDbContext(DbContextOptions<ATRSDbContext> options) : base(options)
        {

        }
        public DbSet<Registration> Registrations { get; set; }
        public DbSet<Flight>Flights { get; set; }
        
    }
}